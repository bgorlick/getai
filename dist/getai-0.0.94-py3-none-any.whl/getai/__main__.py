# __main__.py
import asyncio
from getai.main import main


def run():
    asyncio.run(main())


if __name__ == '__main__':
    run()
